<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDocumentVersionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('document_versions', function (Blueprint $table) {
            $table->id(); // id do individuo
            // $table->unsignedBigInteger('id_document')->nullable(false); // id que conecta qual Documento Principal
            $table->foreignId('id_document')->constrained('documents')->onDelete('cascade');
            // $table->string('name')->nullable(false); // Nome do Documento
            $table->float('version')->nullable(false); // Versão do Documento
            $table->text('description')->nullable(false); // Descrição do novo Documento/Versão
            $table->date('date_document')->nullable(false); // Usuário Informa a Data de criação do Documento
            $table->timestamps(); // Data e Hora que foi inserido no BD
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('document_versions');
    }
}
