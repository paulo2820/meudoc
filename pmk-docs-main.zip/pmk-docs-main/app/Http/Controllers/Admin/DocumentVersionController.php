<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Middleware\Login;
use App\Http\Requests\DocumentVersionEditRequest;
use App\Http\Requests\DocumentVersionRequest;
use App\Http\Requests\SubDocumentRequest;
use App\Models\Document;
use App\Models\DocumentVersion;
use App\Models\SubDocument;
use App\Models\Type;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DocumentVersionController extends Controller
{
    public function __construct()
    {
        $this->middleware(Login::class);
    }

    public function index()
    {
        // Esta variavel passa a existir apartir do momento que houver um cadastro, delete ou edit.
        $mensagemSucesso = session('mensagem.sucesso');

        return view('document-version.index', compact('mensagemSucesso'));
    }

    public function create()
    {
        $id_documents = Document::select('*')
            ->with('types')
            ->orderBy('name')
            ->get();;

        return view('document-version.create', compact('id_documents'));
    }

    public function store(DocumentVersionRequest $request, DocumentVersion $document)
    {

        // Verifico se existe um DOCUMENTO com a VERSÃO que está sendo cadastrado
        $sql = $document->select()
            ->where([
                ['id_document', $request->id_document],
                ['version', $request->version],
            ])
            ->exists();;

        // Caso exista um documento e versão no BD enviar erro
        if ($sql) {
            return redirect()->back()->withErrors(['O Documento já possui essa versão!']);
        }

        // Cria o Documento na Tabela Document Version
        $document = $document->create($request->all());

        // Select e comparar o id_document com o id da Tabela Documents e retornar o Name
        $name = Document::select()
            ->where('id', $request->id_document)
            ->pluck('name');

        return redirect(route('document-version.index'))
            ->with('mensagem.sucesso', "Documento '{$name[0]}' cadastrado com sucesso!");
    }

    // public function show()
    // {
    //     $documents = Document::with("types", "documentVersions")->get();

    //     return view('document-view.index', compact('documents'));
    // }

    public function edit(DocumentVersion $document)
    {
        // Mostra o nome do Documento que está sendo Editado na View
        $name = Document::select()
            ->where('id', $document->id_document)
            ->pluck('name');

        return view('document-version.edit', compact('document', 'name'));
    }

    public function update(DocumentVersion $document, DocumentVersionEditRequest $request)
    {

        $name = Document::select()
            ->where('id', $document->id_document)
            ->pluck('name');

        // ELE PODE SER IGUAL COM ELE MESMO
        $document->version = $request->version;
        $document->description = $request->description;
        $document->save();

        return redirect(route('document-version.index'))
            ->with('mensagem.sucesso', "Documento {$name[0]} {$document->version} Atualizado com Sucesso!");
    }

    public function destroy(Request $request)
    {
        // Busca o documento que vai ser DELETADO mediante ao request junto com JavaScript
        $document = DocumentVersion::find($request->document_version_delete_id);

        // Busca o Nome do Documento Principal referenciado para o Document Version
        $name = Document::select()
            ->where('id', $document->id_document)
            ->pluck('name');

        $document->delete();

        return redirect(route('document-version.index'))
            ->with('mensagem.sucesso', "Documento {$name[0]} Deletado com Sucesso!");
    }

    public function editDuplicate(DocumentVersion $document)
    {
        // document está trazendo o parametro, no caso o id do Document Version
        // select ele, pego as informações: id_document, version, description, date_document
        // Após isso coloco nos inputs para o usuário Editar e por fim duplicar, é necessário que o usúario informe uma nova versão

        // Mostra o nome na view de qual documento está sendo duplicado
        $name = Document::select()
            ->where('id', $document->id_document)
            ->pluck('name');

        return view('document-duplicate.create', compact('document', 'name'));
    }

    public function storeDuplicate(DocumentVersionRequest $request, DocumentVersion $document, $id_document_version, SubDocument $subDocument)
    {

        // Verifico se existe um DOCUMENTO com a VERSÃO que está sendo cadastrado
        $sql = $document->select()
            ->where([
                ['id_document', $request->id_document],
                ['version', $request->version],
            ])
            ->exists();;

        // Caso exista um documento e versão no BD enviar erro
        if ($sql) {
            return redirect()->back()->withErrors(['O Documento já possui essa versão!']);
        } else {
            // Cria o Documento na Tabela Document Version
            $document = $document->create($request->all());

            // id document versions
            $document_id_anterior = $id_document_version;

            // Seleciona os registros que deseja duplicar - Sub Document
            $sub_documents_duplicate = $subDocument->where('id_document_versions', "$document_id_anterior")->get();

            // Copia os registros selecionados para novas linhas na tabela
            $news_sub_documents = [];
            foreach ($sub_documents_duplicate as $sub_documents) {
                $news_sub_documents[] = [
                    'id_document_versions' => $document->id,
                    'type' => $sub_documents->type,
                    'name' => $sub_documents->name,
                    'description' => $sub_documents->description,
                    'date_document' => $sub_documents->date_document,
                ];
            }

            $subDocument->insert($news_sub_documents);
        }

        // Select e comparar o id_document com o id da Tabela Documents e retornar o Name
        $name = Document::select()
            ->where('id', $request->id_document)
            ->pluck('name');

        return redirect(route('document-version.index'))
            ->with('mensagem.sucesso', "Documento '{$name[0]}' cadastrado com sucesso!");
    }
}
