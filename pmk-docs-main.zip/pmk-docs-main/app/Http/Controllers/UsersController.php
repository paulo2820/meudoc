<?php

namespace App\Http\Controllers;

use App\Mail\VerifyEmail;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UsersController extends Controller
{

    public function create()
    {
        return view('users.create');
    }

    // public function store(Request $request)
    // {
    //     $validatorRequest = $request->validate(
    //         [
    //             'name' => ['required', 'min:3', 'max:50'],
    //             'email' => ['required', 'email', 'unique:users,email|max:255'],
    //             'password' => ['required', 'min:6', 'max:12', 'confirmed'],
    //             'password_confirmation' => ['required'],
    //         ],
    //         [
    //             'name.required' => 'Necessário informar um Nome!',
    //             'email.required' => 'Necessário um email válido!',
    //             'email.unique' => 'Este email já está em uso!',
    //             'password.required' => 'Necessário informar uma senha!',
    //             'password.confirmed' => 'Senhas incompativéis!',
    //             'password_confirmation.required' => 'Necessário confirmação da senha!'
    //         ]
    //     );

    //     $validatorRequest['password'] = Hash::make($validatorRequest['password']);

    //     $user = User::create($validatorRequest);

    //     Auth::login($user);

    //     return redirect(route('document-version.index'));
    // }

    public function store(Request $request)
    {
        $validatorRequest = $request->validate(
            [
                'name' => ['required', 'min:3', 'max:50'],
                'email' => ['required', 'email', 'unique:users,email'],
                'password' => ['required', 'min:6', 'max:12', 'confirmed'],
                'password_confirmation' => ['required'],
            ],
            [
                'name.required' => 'Necessário informar um Nome!',
                'email.required' => 'Necessário um email válido!',
                'email.unique' => 'Este email já está em uso!',
                'password.required' => 'Necessário informar uma senha!',
                'password.confirmed' => 'Senhas incompativéis!',
                'password_confirmation.required' => 'Necessário confirmação da senha!'
            ]
        );

        $validatorRequest['password'] = Hash::make($validatorRequest['password']);

        $user = User::create($validatorRequest);

        Auth::login($user);

        return redirect(route('document-version.index'));
    }
}
