<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function index()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        // Credenciais para o momento de Login
        $credentials = $request->validate([
            'email' => ['required','exists:users,email'],
            'password' => ['required'],
        ],
        [
            'email.required' => 'Necessário informar um Email!',
            'password.required' => 'Necessário informar uma Senha!'
        ]

        );

        // Tenta LOGAR usando os dados de quem está cadastrado, verifica por meio da variavel credentials
        if (Auth::attempt($credentials)) {

            // Regenerar o ID da sessão assim criando um novo ID, defesa contra ataque na sessão
            $request->session()->regenerate();

            return redirect(route('document-version.index'));
        }

        // Caso exista um erro na validação, exibe as seguintes mensagens
        return back()->withErrors([
            'email' => 'Email inválido!',
            'password' => 'Senha inválida!',
        ])->onlyInput('email');
    }

    public function logout(Request $request)
    {
        // Logout do usuário logado
        Auth::logout();

        // Sessão fica invalidada
        $request->session()->invalidate();

        // Regenero um novo token
        $request->session()->regenerateToken();

        return redirect(route('login'));
    }
}
