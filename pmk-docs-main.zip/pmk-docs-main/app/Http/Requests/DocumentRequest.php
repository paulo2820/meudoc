<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class DocumentRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name' => ['required', 'max:40'],
            'type' => ['required'],
        ];
    }

    public function messages()
    {
        return [
            'name.required' => 'O campo nome do Documento é obrigatório!',
            'name.max' => 'O nome do Documento pode ter apenas :max caracteres',
            'type.required' => 'Tipo de Documento é obrigátorio!',
        ];
    }
}
