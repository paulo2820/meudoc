<?php

namespace App\Http\Livewire;

use App\Http\Controllers\ViewDocumentController;
use App\Models\{Document, DocumentVersion};
use Livewire\Component;

class DocumentViewVersion extends Component
{
    public $documentVersion;
    public $documentId;
    public $documentSearch = null;
    public $document;

    public function mount()
    {
        // Pega o Parametro passado pela rota Show
        $document = $this->document;

        // Explode na string - parametro, separando nome e versão
        $doc = explode("_", $document);

        // Busco na coluna name na tabela de documents o nome passado pelo parametro e pego seu ID
        $documents = Document::select()
            ->where('name', $doc[0])
            ->value('id')
        ;

        // Busco o mesmo valor de ID com ID Document na tabela de Documents Version
        $documentVersion = DocumentVersion::with('documents', 'subDocuments')
            ->where('id_document', $documents)
            ->get()
            // ->get()
        ;

        // Apos ter pego todas informações na tabela de Document Versions, eu armazeno todos que passaram no criterio
        // Este dado é usado no search do select de versão
        $this->documentVersion = $documentVersion;

        // Faz com que o select já venha selecionado na versão que foi clicada no side bar
        $this->documentId = $doc[1];

        // Comparo e faço filtro e assim retorno na hora a versão que foi clicada
        $this->documentSearch = $this->documentVersion->where('version', $this->documentId);
    }

    public function filterVersionByDocumentVersion()
    {
        // Comparo a coluna versão com o valor retornado do select para fazer o filtro na tabela de versão
        $this->documentSearch = $this->documentVersion->where('version', $this->documentId);
    }

    public function render()
    {
        return view('livewire.document-view-version');
    }
}
