@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <div class="d-flex">
                <div class="col-md-12"><h1 class="mt-4 mb-4 text-center"><strong><em>Criar</strong> <strong class="text-primary">Documento</em></strong></h1></div>
            </div>

            @isset($mensagemSucesso)
                <div class="alert alert-success text-center mt-3">
                    {{ $mensagemSucesso }}
                </div>
            @endisset

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card mb-4">
                <div class="card-body">
                    <div class="row d-flex">
                        <div class="col-md-12 col-xl-6">
                            <form action="{{ route('document.store') }}" method="post">
                                @csrf
                                <div class="form-row">
                                    <div class="form-group col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                        <label for="name">Nome do Documento</label>
                                        <input name="name" class="form-control form-control-lg" type="text" autofocus>
                                    </div>

                                    <div class="form-group col-sm-12 col-md-8 col-lg-9 col-xl-12">
                                        <label for="type">Tipo de Documento</label>
                                        <select name="type" class="form-control form-control-lg">
                                            <option value="">Selecione um Tipo de Documento</option>
                                            @foreach ( $types as $type )
                                                <option value="{{ $type->id }}"> {{ $type->name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>

                                <div class="row mb-4">
                                    <div class="col-md-12 d-flex justify-content-center">
                                        <button type="submit" class="btn btn-primary btn-lg mt-2">Cadastrar</button>
                                    </div>
                                </div>

                            </form>
                        </div>

                        <div class="col-md-12 col-xl-6">
                            <table class="table table-bordered table-sm">
                                <thead>
                                    <tr class="table-success text-center">
                                        <th>Nome do Documento</th>
                                        <th>Tipo do Documento</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>

                                <tbody class="text-center">
                                    @foreach ($documents as $document)
                                        <tr>
                                            <th class="align-middle"> {{ $document->name }} </th>
                                            <th class="align-middle"> {{ ($document->types)->name }} </th>
                                            <th class="align-middle">
                                                <span class="d-flex justify-content-center">
                                                    <a href="{{ route('document.edit', $document->id) }}"
                                                        class="btn btn-primary btn-sm mr-2">
                                                        <i class="fas fa-pen-square"></i>
                                                    </a>
                                                    <button type="button" class="btn btn-sm btn-danger deleteDocumentBtn"
                                                        value="{{ $document->id }}|{{ $document->name }}">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>

                                                    <!-- MODAL DELETE -->
                                                    <div id="deleteModal" class="modal fade" tabindex="-1"
                                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                            <div class="modal-content">
                                                                <form action="{{ route('document.destroy', ['document' => $document->id])}}"
                                                                    method="post">
                                                                    @csrf
                                                                    @method('DELETE')
                                                                    <div class="modal-header bg-primary text-light">
                                                                        <h5 class="modal-title">Exclusão do Projeto</h5>

                                                                        <button type="button" class="close"
                                                                            data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>

                                                                    <div class="modal-body">
                                                                        <input type="hidden" name="document_delete_id"
                                                                            id="document_id">
                                                                        <div class="d-flex justify-content-center">
                                                                            <h3>Você realmente deseja excluir este Projeto?
                                                                            </h3>
                                                                        </div>
                                                                        <div class="d-flex justify-content-center mt-3">
                                                                            <h3 id="document_name" class="text-danger"></h3>
                                                                        </div>
                                                                    </div>

                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-dismiss="modal">Cancelar</button>
                                                                        <button type="submit"
                                                                            class="btn btn-primary">Confirmar</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </span>
                                            </th>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
@endsection

{{-- <div class="form-group col-md-2">
    <label for="version">Versão</label>
    <input type="text" class="form-control form-control-lg">
</div>

<div class="row">
    <div class="col-md-12">
        <textarea name="description" cols="30" rows="10"></textarea>
    </div>
</div> --}}
