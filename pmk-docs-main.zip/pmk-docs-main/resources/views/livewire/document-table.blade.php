<div class="table-responsive">
    <table class="table table-sm shadow ">

        <div class="row mb-3">
            <div class="d-flex justify-content-between">

                <div class="col-sm-7 col-md-5 col-xl-4">
                    <input wire:model="filters.search" class="form-control" placeholder="Procurar Documento...">
                </div>

                <div class="col-sm-2 col-md-2 col-xl-2">
                    <select wire:model="perPage" class="form-control">
                        <option>10</option>
                        <option>25</option>
                        <option>50</option>
                        <option>100</option>
                    </select>
                </div>

            </div>
        </div>

        <thead>
            <tr class="table-success">
                <th class="text-center">
                    Nome do Documento

                </th>
                <th class="text-center">
                    Versão
                </th>
                <th class="text-center">
                    Tipo do Documento
                </th>
                <th class="text-center">
                    Data do Documento
                </th>
                <th class="text-center">Ações</th>
            </tr>
        </thead>

        <tbody>
            @forelse ( $document_versions as $document_version )
                <tr>
                    <th class="text-center"> {{ $document_version->name }} </th>
                    <th class="text-center"> {{ $document_version->version }} </th>
                    <th class="text-center"> {{ $document_version->types->name }} </th>
                    <th class="text-center"> {{ \Carbon\Carbon::parse($document_version->date_document)->format('d/m/Y') }}</th>

                    <th>
                        <span class="d-flex justify-content-center">
                            <a href="{{ route('view-document.show', ['document' => $document_version->name . '_' . $document_version->version]) }}"
                                class="btn btn-info btn-sm mr-2 text-light">
                                <i class="fas fa-eye"></i>
                            </a>

                            <a href="{{ route('document-version.edit', ['document' => $document_version->id]) }}"
                                class="btn btn-primary btn-sm mr-2">
                                <i class="fas fa-pen-square"></i>
                            </a>

                            <a href="{{ route('document-version.edit-duplicate', ['document' => $document_version->id]) }}"
                                class="btn btn-warning btn-sm mr-2">
                                <i class="far fa-copy"></i>
                            </a>

                            <button type="button" class="btn btn-sm btn-danger deleteDocumentVersionBtn"
                                value="{{ $document_version->id }}|{{ $document_version->name }}">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </span>
                    </th>
                </tr>

                <!-- MODAL DELETE -->
                <div id="deleteModal" class="modal fade" tabindex="-1" aria-labelledby="Modal Delete"
                    aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <form action="{{ route('document-version.destroy', ['document' => $document_version->id]) }}"
                                method="post">
                                @csrf
                                @method('DELETE')
                                <div class="modal-header bg-primary text-light">
                                    <h5 class="modal-title">Exclusão do Documento</h5>

                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    <input type="hidden" name="document_version_delete_id"
                                        id="document_version_id">
                                    <div class="d-flex justify-content-center">
                                        <h4 class="text-center">Você realmente deseja excluir este Documento?</h4>
                                        <br>
                                    </div>
                                    <div class="d-flex justify-content-center mt-3">
                                        <h4 id="document_version_name" class="text-danger text-center"></h4>
                                    </div>
                                </div>

                                <div class="modal-footer d-flex justify-content-center">
                                    <button type="button" class="btn btn-secondary"
                                        data-dismiss="modal">Cancelar</button>
                                    <button type="submit" class="btn btn-primary">Confirmar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            @empty

            <tr>
                <td class="text-center" colspan="4">
                    <h2 class="p-3">Documento não encontrado!</h2>
                </td>
            </tr>

            @endforelse
        </tbody>
    </table>

    {{-- <div class="row">
        <div class="d-flex justify-content-center">
            {{ $document_versions->links() }}
        </div>
    </div> --}}

</div>
