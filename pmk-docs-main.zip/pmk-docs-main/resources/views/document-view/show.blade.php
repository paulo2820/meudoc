@extends('template.document-index')
@section('content')
    <!-- CONTENT -->

    <div class="docs-content">

        <article class="docs-article">
            <livewire:document-view-version :document="$document" />
        </article>

    </div>
    <!-- CONTENT -->
@endsection
