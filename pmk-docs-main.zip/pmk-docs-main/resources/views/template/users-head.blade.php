<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">

<title>PMK - Criação de Usuário</title>

<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.15.2/styles/atom-one-dark.min.css">

<link rel="stylesheet" href="{{ asset("assets/plugins/simplelightbox/simple-lightbox.min.css") }}">
<link rel="icon" type="image/svg" href="{{ asset("assets/images/favico-pmk.svg") }}" />
<link id="theme-style" rel="stylesheet" href="{{ asset("assets/css/theme.css") }}">
<link rel="stylesheet" href="{{ asset("assets/css/style.css") }}">

<script defer src="{{ asset("assets/fontawesome/js/all.min.js") }}"></script>
