<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-light shadow " id="sidenavAccordion">
        <div class="sb-sidenav-menu border-right">
            <div class="nav">
                <div class="sb-sidenav-menu-heading text-primary">
                    Interface - Visualização
                </div>

                <a href="{{ route('document-version.index') }}" class="nav-link">
                    <div class="sb-nav-link-icon d-flex align-items-center">
                        <i class="far fa-eye size-icon"></i>
                    </div>
                    <span>Documentos Principais<span>
                </a>

                <a href="{{ route('sub-document.index') }}" class="nav-link">
                    <div class="sb-nav-link-icon d-flex align-items-center">
                        <i class="far fa-eye size-icon"></i>
                    </div>
                    <span>Visualizar Sub Documentos<span>
                </a>

                <a href="{{ route('view-document.index') }}" class="nav-link">
                    <div class="sb-nav-link-icon d-flex align-items-center">
                        <i class="far fa-eye size-icon"></i>
                    </div>
                    <span>Visualizar Documentação</span>
                </a>

                <div class="sb-sidenav-menu-heading text-primary border-top">
                    Interface - Criação de Documento
                </div>

                <a href=" {{ route('document-version.create') }} " class="nav-link">
                    <div class="sb-nav-link-icon d-flex align-items-center">
                        <i class="fas fa-file-signature size-icon"></i>
                    </div>
                    <span>Documento Principal<span>
                </a>

                <a href="{{ route('sub-document.create') }}" class="nav-link">
                    <div class="sb-nav-link-icon d-flex align-items-center">
                        <i class="fas fa-file-signature size-icon"></i>
                    </div>
                    <span>Sub Documento<span>
                </a>

                <div class="sb-sidenav-menu-heading text-primary border-top">
                    Interface - Cadastro
                </div>

                <a href="{{ route('document.create') }}" class="nav-link">
                    <div class="sb-nav-link-icon d-flex align-items-center">
                        <i class="far fa-file-alt size-icon"></i>
                    </div>
                    <span>Documento<span>
                </a>

                {{-- NAO EXISTE MAIS --}}
                {{-- <a href="{{ route('sub-document.create') }}  " class="nav-link">
                    <div class="sb-nav-link-icon d-flex align-items-center">
                        <i class="far fa-file-alt size-icon"></i>
                    </div>
                    <span>Sub Documento<span>
                </a> --}}

                <a href="{{ route('type.create') }}" class="nav-link">
                    <div class="sb-nav-link-icon d-flex align-items-center">
                        <i class="far fa-file-alt size-icon"></i>
                    </div>
                    <span>Tipo de Documento</span>
                </a>

                <div class="sb-sidenav-menu-heading text-primary border-top">
                    Interface - Arquivos
                </div>

                <a href="{{ route('files.index') }}" class="nav-link">
                    <div class="sb-nav-link-icon d-flex align-items-center">
                        <i class="fas fa-file-export size-icon"></i>
                    </div>
                    <span>Arquivos<span>
                </a>
            </div>
        </div>

        <div class="sb-sidenav-footer border-right">
            <div class="small">Usuário Logado:</div>
            {{auth()->user()->name}}
        </div>
    </nav>
</div>
