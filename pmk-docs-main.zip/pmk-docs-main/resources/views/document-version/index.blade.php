@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4 mb-4 col-md-12 text-center"><strong><em>Visualizar</strong> <strong class="text-primary">Documentos</em></strong></h1>

            @isset($mensagemSucesso)
                <div class="alert alert-success text-center mt-3">
                    {{ $mensagemSucesso }}
                </div>
            @endisset

            <div class="card">
                <div class="card-body">
                    <livewire:document-table />
                </div>
            </div>
        </div>
    </main>
    @livewireScripts()
@endsection
