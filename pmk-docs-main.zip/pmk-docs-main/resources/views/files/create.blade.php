@extends('template.index')

@section('content')

<main>
    <div class="container-fluid px-4">
        <div class="d-flex">
            <div class="col-md-12"><h1 class="mt-4 mb-4 text-center"><strong><em>Upload de</strong> <strong class="text-primary">Arquivos</em></strong></h1></div>
        </div>

        @if(!empty($mensagem))
            <div class="alert alert-{{ isset($mensagem['sucess']) ? 'success':'danger' }} text-center mt-3">
                {{ isset($mensagem['sucess']) ? $mensagem['sucess'] : $mensagem['error'] }}
            </div>
        @endif

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div class="card mb-4">
            <div class="card-body">
                <div class="row d-flex">
                    <div class="col-12">
                        <form action="{{ route('files.store')}} " method="post" enctype="multipart/form-data">
                            @csrf
                            <div class="row">
                                <div class="d-flex align-items-center justify-content-center">
                                    <div class="col-md-12">
                                        <label for="file">Upload de Arquivos: Imagens, Vídeos e PDF</label>
                                        <input name="file" class="form-control form-control-lg" placeholder="Insira o link aqui..." type="file" accept=".jpg, .jpeg, .pdf" autofocus>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="d-flex align-items-center justify-content-center col-md-12">
                                    <button type="submit" class="btn btn-primary btn-lg mt-3">Registrar</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        @if (isset($path))
            <p>O arquivo foi enviado com sucesso:</p>
            <a href="{{ asset('storage/' . $path) }}">{{ $path }}</a>
        @endif

    </div>
</main>

@endsection
