@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="mt-4 mb-4 text-center"><strong><em>Visualização</strong> <strong class="text-primary">Arquivos</em></strong></h1>
                </div>
            </div>

            <div class="row mb-2">
                <div class="col-md-12 d-flex">
                    <div>
                        <a href="{{ route('files.create') }}" class="btn btn-primary">
                            Registrar
                        </a>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <livewire:file-table />
                </div>
            </div>
    </main>
    @livewireScripts()
@endsection
