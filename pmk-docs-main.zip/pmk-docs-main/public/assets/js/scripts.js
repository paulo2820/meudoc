$(document).ready(function()
{
    // Deletar Documento Princiapl Versão
    $('.deleteDocumentVersionBtn').click(function(e){
        e.preventDefault();

        const document_version_id = $(this).val();
        const result = document_version_id.split("|");

        $('#document_version_id').val(result[0]);
        $('#document_version_name').text(result[1]);
        $('#deleteModal').modal('show');
    });

    // Deletar Documento
    $('.deleteDocumentBtn').click(function(e){
        e.preventDefault();

        const document_id = $(this).val();
        const result = document_id.split("|");

        $('#document_id').val(result[0]);
        $('#document_name').text(result[1]);
        $('#deleteModal').modal('show');
    });

    // Deletar Sub Documento
    $('.deleteSubDocumentBtn').click(function(e){
        e.preventDefault();

        const sub_document_id = $(this).val();
        const result = sub_document_id.split("|");

        $('#sub_document_id').val(result[0]);
        $('#sub_document_name').text(result[1]);
        $('#deleteModal').modal('show');
    });

    // Deletar Tipo de Documento
    $('.deleteTypeBtn').click(function(e){
        e.preventDefault();

        const type_id = $(this).val();
        const result = type_id.split("|");

        $('#type_id').val(result[0]);
        $('#type_name').text(result[1]);
        $('#deleteModal').modal('show');
    });

    // Deletar Arquivos
    $('.deleteFile').click(function(e){
        e.preventDefault();

        const file_delete_id = $(this).val();
        const result = file_delete_id.split("|");

        $('#file_delete_id').val(result[0]);
        $('#file_name').text(result[1]);
        $('#deleteModal').modal('show');
    });

    $('body').on('click', '.preview', function(e){
        e.preventDefault();

        const image_name = $(this).val();
        const result = image_name.split("|");
        const pdfUrl = result[1];

        $('#pdf-viewer').attr('src', pdfUrl);

        $('#image_name').text(result[0]);
        $('#image_path').attr("src", result[1]);

        $('#previewModal').modal('show');
    });

    $('.close').on('click', function() {
        $('#pdf-viewer').attr('src', '');
    });
});

// Obtém o elemento input date
const inputDate = $("#date_document");

// Cria um objeto Date com a data atual
const now = new Date();
const formattedDate = now.getFullYear() + "-" + (now.getMonth() + 1).toString().padStart(2, "0") + "-" + now.getDate().toString().padStart(2, "0");

// Define o valor do campo input date para a data atual
inputDate.val(formattedDate);
