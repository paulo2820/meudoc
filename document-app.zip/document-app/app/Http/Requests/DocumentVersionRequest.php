<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class DocumentVersionRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'id_document' => ['required'],
            'version' => ['required', 'max:4'],
            'description' => ['required'],
        ];
    }

    public function messages()
    {
        return [
            'id_document.required' => 'O Campo Documento é obrigatório',
            'version.required' => 'O nome do Documento pode ter apenas :max caracteres',
            'version.max' => 'A versão pode ter apenas 4 caracteres',
            'description.required' => 'É necessário informar uma Descrição para o Documento.',
        ];
    }
}
