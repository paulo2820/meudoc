<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class DocumentVersionEditRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'version' => ['required', 'max:4'],
            'description' => ['required'],
        ];
    }

    public function messages()
    {
        return [
            'version.required' => 'O campo Versão é obrigatório.',
            'name.max' => 'A versão pode ter :max caracteres.',
            'description.required' => 'A Descrição do Documento é Obrigatório.',
        ];
    }
}
