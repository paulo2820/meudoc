<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SubDocumentRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name' => ['required', 'max:20'],
            'id_document_versions' => ['required'],
            'type' => ['required'],
            'description' => ['required']
        ];
    }

    public function messages()
    {
        return [
            'name.required' => 'É necessário informar um nome!',
            'name.max' => 'O nome do Cliente pode ter apenas :max caracteres',
            'id_document_versions.required' => 'Necessário Informar o campo Documentação',
            'type.required' => 'Necessário Informar o campo Tipo de Documento',
            'description.required' => 'Necessário uma Descrição para o Sub Documento',
        ];
    }
}
