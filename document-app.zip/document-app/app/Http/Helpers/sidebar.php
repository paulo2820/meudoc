<?php

use App\Models\Document;
use App\Models\DocumentVersion;
use Illuminate\Support\Facades\DB;

function document()
{
    $viewDocuments = Document::query()
        ->with('types', 'documentVersions')
        ->get();
    ;

    return $viewDocuments;
}

function version()
{
    $versionLast = DocumentVersion::select('id_document', DB::raw('MAX(version) as max_version'))
        ->groupBy('id_document')
        ->get();
    ;

    return $versionLast;
}

?>
