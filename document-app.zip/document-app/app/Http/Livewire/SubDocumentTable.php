<?php

namespace App\Http\Livewire;

use App\Models\Document;
use App\Models\DocumentVersion;
use App\Models\SubDocument;
use Illuminate\Support\Facades\DB;
use Livewire\Component;
use Livewire\WithPagination;

class SubDocumentTable extends Component
{
    use WithPagination;

    public $sorts = [

    ];

    public $filters = [
        "search" => "",
    ];

    public $perPage = 10;

    public function mount() {
        $this->perPage = session()->get('perPage', 10);
    }

    public function updatedPerPage($value) {
        $this->resetPage();

        session()->put('perPage', $value);
    }

    public function sortBy($column) {
        if(!isset($this->sorts[$column])) {
            return $this->sorts[$column] = 'asc';
        }

        if( $this->sorts[$column] === 'asc') {
            return $this->sorts[$column] = 'desc';
        }

        unset($this->sorts[$column]);
    }

    public function applySorting($query) {
        foreach($this->sorts as $column => $direction) {
            $query->orderBy($column, $direction);
        }

        return $query;
    }

    // Hook Lifecile
    public function updatedFilters() {
        $this->resetPage();
    }

    public function runQueryBuilder() {
        // $query = SubDocument::query()
        //     ->when($this->filters['search'], function($query, $search) {
        //         $query->where("name", "like", "%$search%");
        //     });

        // $query = Document::join('document_versions', 'documents.id', 'id_document')
        //     ->join('sub_documents', 'document_versions.id', 'sub_documents.id_document_versions')
        //     ->get([
        //         'documents.name as document_name',
        //         'document_versions.version',
        //         'sub_documents.name',
        //     ])
        // ;

        $query = Document::join('document_versions', 'documents.id', 'id_document')
            ->join('sub_documents', 'document_versions.id', 'sub_documents.id_document_versions')
            ->where('sub_documents.name', 'like', "%" . $this->filters['search'] . "%")
            ->orWhere('documents.name', 'like', "%" . $this->filters['search'] . "%")
            ->orWhere('document_versions.version', 'like', "%" . $this->filters['search'] . "%")
            ->paginate($this->perPage, [
                'documents.name as document_name',
                'document_versions.version',
                'sub_documents.name',
                'sub_documents.id',
            ]);

        // dd($query->toArray());
        // dd($query);

        return $this->applySorting($query);
    }

    public function render() {

        return view('livewire.sub-document-table', [
            // 'documents' => $this->runQueryBuilder()->simplePaginate($this->perPage),
            'documents' => $this->runQueryBuilder(),
        ]);
    }
}
