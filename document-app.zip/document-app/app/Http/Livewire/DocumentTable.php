<?php

namespace App\Http\Livewire;

use App\Models\Document;
use App\Models\DocumentVersion;
use Livewire\Component;
use Livewire\WithPagination;

class DocumentTable extends Component
{
    use WithPagination;

    public $sorts = [

    ];

    public $filters = [
        "search" => "",
    ];

    public $perPage = 10;

    public function mount() {
        $this->perPage = session()->get('perPage', 10);
    }

    public function updatedPerPage($value) {
        $this->resetPage();

        session()->put('perPage', $value);
    }

    public function sortBy($column) {
        if(!isset($this->sorts[$column])) {
            return $this->sorts[$column] = 'asc';
        }

        if( $this->sorts[$column] === 'asc') {
            return $this->sorts[$column] = 'desc';
        }

        unset($this->sorts[$column]);
    }

    public function applySorting($query) {
        foreach($this->sorts as $column => $direction) {
            $query->orderBy($column, $direction);
        }

        return $query;
    }

    // Hook Lifecile
    public function updatedFilters() {
        $this->resetPage();
    }

    public function runQueryBuilder() {
        // $query = Document::query()
        //     ->when($this->filters['search'], function($query, $search) {
        //         $query->where("name", "like", "%$search%");
        //     });

        $query = Document::join('document_versions', 'documents.id', 'id_document')
            ->where('name', 'like', "%" . $this->filters['search'] . "%")
            ->orWhere('version', 'like', "%" . $this->filters['search'] . "%")
            ->paginate($this->perPage);
            // ->toSql();

            // dd($sql);


        return $this->applySorting($query);
    }

    public function render() {
        return view('livewire.document-table', [
            'document_versions' => $this->runQueryBuilder(),
            // 'document_versions' => DocumentVersion::paginate($this->perPage)
        ]);
    }
}
