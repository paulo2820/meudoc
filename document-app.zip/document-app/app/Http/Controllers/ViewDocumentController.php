<?php

namespace App\Http\Controllers;

class ViewDocumentController extends Controller
{
    public function index()
    {
        return view('document-view.index');
    }

    public function show($document)
    {
        return view('document-view.show')->with('document', $document);
    }
}
