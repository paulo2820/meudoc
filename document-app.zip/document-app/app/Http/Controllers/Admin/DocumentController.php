<?php

# ----------------------- DOCUMENTOS BUSSINESS RULE - REGRA DE NEGÓCIO - PAI ----------------------- #

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Middleware\Login;
use App\Http\Requests\DocumentRequest;
use App\Models\Document;
use App\Models\Type;
use Illuminate\Http\Request;

class DocumentController extends Controller
{

    public function __construct()
    {
        $this->middleware(Login::class);
    }

    public function index()
    {
        $documents = Document::with("types", "documentVersions")->get();

        // dd($documents);

        $mensagemSucesso = session('mensagem.sucesso');

        return view('document.index')
            ->with('documents', $documents)
            ->with('mensagemSucesso', $mensagemSucesso);
    }

    public function create()
    {
        $documents = Document::with("types")
            ->orderBy('name')
            ->get()
        ;

        $types = Type::select('*')
            ->orderBy('name')
            ->get()
        ;

        $mensagemSucesso = session('mensagem.sucesso');

        return view('document.create',compact('documents', 'types' ,'mensagemSucesso'));
    }

    public function store(DocumentRequest $request)
    {
        // Criando Documento na tabela documents
        $document = Document::create($request->all());

        // $document->update(['id_document' => $document->id]);

        return redirect(route('document.create'))
            ->with('mensagem.sucesso', "Documento '{$document->name}' cadastrado com sucesso!");
    }

    public function show(Document $document)
    {
        //
    }

    public function edit(Document $document)
    {
        $types = Type::select('*')
            ->orderBy('name')
            ->get()
        ;

        return view('document.edit', compact('document', 'types'));
    }

    public function update(Document $document, DocumentRequest $request)
    {
        $document->name = $request->name;
        $document->type = $request->type;
        $document->save();

        return redirect(route('document.create'))
            ->with('mensagem.sucesso', "Documento '{$document->name}' atualizado com sucesso!");
    }

    public function destroy (Request $request)
    {
        $document = Document::find($request->document_delete_id);

        dd($document);

        if(isset($document)) {
            $document->delete();
        }

        $request->session()->flash('mensagem.sucesso', 'Documente deletado com sucesso!');

        return redirect(route('document.create'))
            ->with('mensagem.sucesso', "Documento '{$document->name}' removido com sucesso!");
    }
}
