<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Document extends Model
{
    use HasFactory;

    protected $table = 'documents';

    protected $fillable = ['id_document', 'type', 'name'];

    // Um documento tem um tipo
    public function types()
    {
        return $this->hasOne(Type::class, "id", "type");
    }

    // Um documento tem varias versões
    public function documentVersions()
    {
        return $this->hasMany(DocumentVersion::class, "id_document", "id");
    }
}
