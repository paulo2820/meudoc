<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">

            <h1 class="mt-4"><strong><em>Alterar nome do</strong> <strong class="text-primary">Tipo de Documento</em></strong></h1>

            <div class="card mb-4">

                <div class="card-body">
                    <div class="row d-flex">
                        <div class="col-6">
                            <form action="<?php echo e(route('type.update', $type->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <label for="name">Alterar nome do Projeto</label>
                                        <input name="name" value="<?php echo e($type->name); ?>" class="form-control form-control-lg" type="text">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 d-flex justify-content-center">
                                        <button type="submit" class="btn btn-primary btn-lg mt-2">Atualizar</button>
                                    </div>
                                </div>

                                <?php if(isset($mensagemSucesso)): ?>
                                <div class="row mt-2">
                                    <div class="d-flex col-12 alert alert-success justify-content-center">
                                        <?php echo e($mensagemSucesso); ?>

                                    </div>
                                </div>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\document-app\resources\views/type/edit.blade.php ENDPATH**/ ?>