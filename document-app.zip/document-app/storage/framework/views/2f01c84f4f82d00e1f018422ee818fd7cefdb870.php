<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">
            <div class="d-flex">
                <div class="col-6"><h1 class="mt-4 mb-4"><strong><em>Criar</strong> <strong class="text-primary">Sub Documento</em></strong></h1></div>
            </div>

            <?php if(isset($mensagemSucesso)): ?>
                <div class="alert alert-success text-center mt-3">
                    <?php echo e($mensagemSucesso); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="card mb-4">
                <div class="card-body">
                    <div class="row d-flex">
                        <div class="col-12">
                            <form action="<?php echo e(route('sub-document.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-row">

                                    <div class="form-group col-md-4">
                                        <label for="name">Nome do Sub Documento</label>
                                        <input name="name" class="form-control form-control-lg" type="text" value="<?php echo e(old('name')); ?>">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="id_document_versions">Documentação</label>
                                        <select name="id_document_versions" class="form-control form-control-lg">
                                            <option value="">Selecione o Documento</option>
                                            <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = $document->documentVersions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documentVersion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($documentVersion->id); ?>" <?php if(old('id_document_versions') == $documentVersion->id): ?> selected <?php endif; ?>> <?php echo e($document->name); ?> - <?php echo e($documentVersion->version); ?> - <?php echo e(($document->types)->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-2">
                                        <label for="type">Tipo do Documento</label>
                                        <select name="type" class="form-control form-control-lg">
                                            <option value="">Selecione o Tipo</option>
                                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($type->id); ?>" <?php if(old('type') == $type->id): ?> selected <?php endif; ?>> <?php echo e($type->name); ?> </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-2">
                                        <label for="date_document">Data</label>
                                        <input type="date" class="form-control form-control-lg" id="date_document" name="date_document">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <textarea name="description" cols="30" rows="10"> <?php echo e(old('description')); ?> </textarea>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12 d-flex justify-content-center">
                                        <button type="submit" class="btn btn-primary btn-lg mt-2">Cadastrar</button>
                                    </div>
                                </div>

                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\document-app\resources\views/sub-document/create.blade.php ENDPATH**/ ?>