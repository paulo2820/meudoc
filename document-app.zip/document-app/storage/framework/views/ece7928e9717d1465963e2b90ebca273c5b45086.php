<section class="docs-section shadow mt-3">
    <div class="p-3">
        <div class="row mb-4">
            <div class="col-12 d-flex justify-content-center">
                <div class="col-md-2">
                    <label for="">Versões</label>
                    <select class="form-select" wire:model="documentId" wire:change="filterVersionByDocumentVersion">
                        <?php $__currentLoopData = $documentVersion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documentVersion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($documentVersion->version); ?>"> <?php echo e($documentVersion->version); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-3">
                    <label for="">Sub Documentos</label>
                    <select id="select-text" class="form-select">
                        <option value=""> Selecione um Sub Documento </option>
                        <?php if($documentSearch): ?>
                            <?php $__currentLoopData = $documentSearch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $document->subDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subDocument): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subDocument->name); ?>"> <?php echo e($subDocument->name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
            </div>
        </div>

        <?php if($documentSearch): ?>
            <?php $__currentLoopData = $documentSearch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php $__currentLoopData = $document->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <section>
                        <h1 class="docs-heading"> <?php echo $doc->name; ?> <?php echo e($document->version); ?> - <?php echo ($doc->types)->name; ?></h1>
                        <p><?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d', $document->date_document)->format('d/m/Y')); ?></p>
                        <p><?php echo $document->description; ?></p>
                    </section>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <?php $__currentLoopData = $document->subDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subDocument): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <section class="docs-section" id="<?php echo $subDocument->name; ?>">
                        <h2 class="section-heading"># <?php echo $subDocument->name; ?></h2>
                        <p><?php echo $subDocument->description; ?></p>
                    </section>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</section>





<?php /**PATH C:\www\document-app\resources\views/livewire/document-view-version.blade.php ENDPATH**/ ?>