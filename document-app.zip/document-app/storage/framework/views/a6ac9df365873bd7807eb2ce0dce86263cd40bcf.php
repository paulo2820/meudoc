<?php $__env->startSection('content'); ?>
    <!-- CONTENT -->

    <div class="docs-content">

        <article class="docs-article">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('document-view-version', ['document' => $document])->html();
} elseif ($_instance->childHasBeenRendered('NYdYAUU')) {
    $componentId = $_instance->getRenderedChildComponentId('NYdYAUU');
    $componentTag = $_instance->getRenderedChildComponentTagName('NYdYAUU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NYdYAUU');
} else {
    $response = \Livewire\Livewire::mount('document-view-version', ['document' => $document]);
    $html = $response->html();
    $_instance->logRenderedChild('NYdYAUU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </article>

    </div>
    <!-- CONTENT -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.document-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\document-app\resources\views/document-view/show.blade.php ENDPATH**/ ?>