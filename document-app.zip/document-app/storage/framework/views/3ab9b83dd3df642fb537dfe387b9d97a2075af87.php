<!DOCTYPE html>
<html lang="pt-br">
<head>
    <?php echo $__env->make('template.document-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="docs-page">

    <header class="header fixed-top">
        <?php echo $__env->make('template.document-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo \Livewire\Livewire::styles(); ?>

    </header>

    <div class="docs-wrapper">
        <?php echo $__env->make('template.document-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php echo $__env->make('template.document-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
<?php /**PATH C:\www\document-app\resources\views/template/document-index.blade.php ENDPATH**/ ?>