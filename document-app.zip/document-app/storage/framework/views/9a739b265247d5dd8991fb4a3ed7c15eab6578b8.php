<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4 mb-4"><strong><em>Criar</strong> <strong class="text-primary">Cliente</em></strong></h1>
            <div class="card mb-4">

                <div class="card-body">

                    <div class="row d-flex">
                        <div class="col-6">
                            <table class="table table-bordered table-sm">
                                <thead>
                                    <tr class="table-success text-center align-middle">
                                        <th>Clientes</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>

                                <tbody class="text-center">

                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th class="align-middle"><?php echo e($client->name); ?></th>
                                            <th class="align-middle">

                                                <span class="d-flex justify-content-center">
                                                    <a href="<?php echo e(route('client.edit', $client->id)); ?>" class="btn btn-primary btn-sm mr-2" value="<?php echo e($client->name); ?>">
                                                        <i class="fas fa-pen-square"></i> Editar
                                                    </a>

                                                    <button type="button" class="btn btn-sm btn-danger deleteClientBtn" value="<?php echo e($client->id); ?>|<?php echo e($client->name); ?>">
                                                        Excluir
                                                    </button>


                                                    <!-- MODAL DELETE -->
                                                    <div id="deleteModal"  class="modal fade" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                            <div class="modal-content">
                                                                <form action="<?php echo e(route('client.destroy', ['client' => $client->id])); ?>" method="post">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <div class="modal-header bg-primary text-light">
                                                                        <h5 class="modal-title">Exclusão do Cliente</h5>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <input type="hidden" name="client_delete_id" id="client_id">
                                                                        <div class="d-flex justify-content-center">
                                                                            <h3>Você realmente deseja excluir este Cliente?</h3>
                                                                        </div>
                                                                        <div class="d-flex justify-content-center mt-3">
                                                                            <h3 id="client_name" class="text-danger"></h3>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                                                        <button type="submit" class="btn btn-primary">Confirmar</button>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </span>
                                            </th>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="col-6">
                            <form action="<?php echo e(route('client.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <label for="name">Nome do Cliente</label>
                                        <input name="name" class="form-control form-control-lg" type="text" autofocus>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 d-flex justify-content-center">
                                        <button type="submit" class="btn btn-primary btn-lg mt-2">Cadastrar</button>
                                    </div>
                                </div>
                                <?php if(isset($mensagemSucesso)): ?>
                                <div class="row mt-2">
                                    <div class="d-flex col-12 alert alert-success justify-content-center">
                                        <?php echo e($mensagemSucesso); ?>

                                    </div>
                                </div>
                                <?php endif; ?>

                                <?php if($errors->any()): ?>
                                <div class="alert alert-danger ml-5 mt-3 d-flex justify-content-center">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <?php endif; ?>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\document-app\resources\views/client/create.blade.php ENDPATH**/ ?>