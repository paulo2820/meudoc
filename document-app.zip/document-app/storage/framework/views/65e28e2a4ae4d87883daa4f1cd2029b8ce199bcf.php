<div class="container-fluid px-4">
    <div class="d-flex align-items-center justify-content-center small">
        <div class="text-muted">PMK Docs System &copy; 2023</div>
    </div>
</div>
<?php /**PATH C:\www\document-app\resources\views/template/footer.blade.php ENDPATH**/ ?>