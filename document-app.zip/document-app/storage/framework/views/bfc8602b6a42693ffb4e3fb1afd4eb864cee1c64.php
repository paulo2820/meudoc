<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <?php echo $__env->make('template.auth-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>

	<body class="p-0">
        <?php echo $__env->yieldContent('content'); ?>
	</body>

    <?php echo $__env->make('template.auth-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php /**PATH C:\www\document-app\resources\views/template/login-index.blade.php ENDPATH**/ ?>