<div>
    <table class="table table-sm table-bordered table-responsive-sm shadow ">

        <div class="row mb-3">
            <div class="d-flex justify-content-between">

                <div class="col-3">
                    <input wire:model="filters.search" class="form-control" placeholder="Procurar Documento...">
                </div>

                <div class="col-2">
                    <select wire:model="perPage" class="form-control">
                        <option>10</option>
                        <option>25</option>
                        <option>50</option>
                        <option>100</option>
                    </select>
                </div>

            </div>
        </div>

        <thead>
            <tr class="table-success">
                <th class="text-center">
                    <span wire:click="sortBy('name')" style="cursor: pointer;">
                        Nome do Documento
                    </span>
                </th>
                <th class="text-center">
                    <span wire:click="sortBy('id_client')" style="cursor: pointer;">
                        Empresa Cliente
                    </span>
                </th>
                <th class="text-center">
                    <span wire:click="sortBy('id_project')"style="cursor: pointer;">
                        Nome do Sistema
                    </span>
                </th>
                <th class="text-center">Ações</th>
            </tr>
        </thead>
        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th class="text-center"><?php echo e($document->name); ?></th>
                    <th class="text-center"><?php echo e(optional($document->client)->name); ?></th>
                    <th class="text-center"><?php echo e(optional($document->project)->name); ?></th>
                    <th>
                        <span class="d-flex justify-content-center">
                            <a href=""
                                class="btn btn-info btn-sm mr-2 text-light">
                                <i class="fas fa-eye"></i>
                            </a>

                            <a href=""
                                class="btn btn-primary btn-sm mr-2">
                                <i class="fas fa-pen-square"></i>
                            </a>

                            <button type="button" class="btn btn-sm btn-danger deleteBussinessBtn"
                                value="<?php echo e($document->id); ?>|<?php echo e($document->name); ?>">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </span>
                    </th>
                </tr>

                <!-- MODAL DELETE -->
                <div id="deleteModal" class="modal fade" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <form action="" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <div class="modal-header bg-primary text-light">
                                    <h5 class="modal-title">Exclusão do Documento</h5>

                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    <input type="hidden" name="bussiness_delete_id" id="bussiness_id">
                                    <div class="d-flex justify-content-center">
                                        <h4 class="text-center">Você realmente deseja excluir este Documento?</h4><br>
                                    </div>
                                    <div class="d-flex justify-content-center mt-3">
                                        <h4 id="bussiness_name" class="text-danger text-center"></h4>
                                    </div>
                                </div>

                                <div class="modal-footer d-flex justify-content-center">
                                    <button type="button" class="btn btn-secondary"
                                        data-dismiss="modal">Cancelar</button>
                                    <button type="submit" class="btn btn-primary">Confirmar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <tr>
                    <th class="text-center p-5" colspan="4">
                        <h3>Documento não encontrado!!!</h3>
                    </th>
                </tr>

                <?php endif; ?>
        </tbody>
    </table>
    <div class="row">
        <div class="d-flex justify-content-center">
            <?php echo e($documents->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\www\document-app\resources\views/livewire/bussiness-rule-sub-table.blade.php ENDPATH**/ ?>