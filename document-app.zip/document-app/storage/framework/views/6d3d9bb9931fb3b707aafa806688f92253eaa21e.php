<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4 mb-4"><strong><em>Editar Documento:</strong> <strong class="text-primary"> <?php echo e($document->name); ?> <?php echo e($document->version); ?> </em></strong></h1>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="card mb-4">
                <div class="card-body">
                    <form action="<?php echo e(route('sub-document-version.update', ['document' => $document])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="form-row">

                            <div class="form-group col-md-5">
                                <label for="name">Editar Nome do Documento</label>
                                <input name="name" class="form-control form-control-lg" type="text" value="<?php echo e($document->name); ?>">
                            </div>

                            <div class="form-group col-md-2">
                                <label for="version">Versão do Documento</label>
                                <input name="version" class="form-control form-control-lg" type="text" value="<?php echo e($document->version); ?>">
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <textarea name="description" cols="30" rows="10"> <?php echo e($document->description); ?> </textarea>
                                </div>
                            </div>

                        </div>

                        <div class="row">
                            <div class="col-md-12 d-flex justify-content-center">
                                <button type="submit" class="btn btn-primary btn-lg mt-2">Atualizar</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\document-app\resources\views/sub-document-version/edit.blade.php ENDPATH**/ ?>