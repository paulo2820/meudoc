<?php $__env->startSection('content'); ?>
    <section class="vh-100 pt-0">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="container-fluid h-custom">
            <div class="row d-flex justify-content-center align-items-center h-100">
                
                <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1 border shadow">
                    <form method="post">
                        
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="row mb-5">
                            <div class="d-flex justify-content-center mt-3">
                                <h1>PMK<em class="text-primary">Docs</em></h1>
                            </div>
                            <div class="d-flex justify-content-center border-bottom">
                                <h1>Cadastro</h1>
                            </div>
                        </div>

                        <div class="row form-outline mb-5">
                            <div class="d-flex justify-content-start">
                                <label class="form-label" for="name">Nome:</label>
                            </div>
                            <div class="d-flex justify-content-center">
                                <input type="name" name="name" id="name" value="<?php echo e(old('name')); ?>" class="form-control form-control-lg"
                                    placeholder="Informe seu nome" />
                            </div>
                        </div>

                        <!-- Email input -->
                        <div class="row form-outline mb-5">
                            <div class="d-flex justify-content-start">
                                <label class="form-label" for="email">Endereço de email:</label>
                            </div>
                            <div class="d-flex justify-content-center">
                                <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" class="form-control form-control-lg"
                                    placeholder="Informe seu email" />
                            </div>
                        </div>

                        <!-- Password input -->
                        <div class="row form-outline mb-5">
                            <div class="d-flex justify-content-start">
                                <label class="form-label" for="password">Senha:</label>
                            </div>
                            <div class="d-flex justify-content-center">
                                <input type="password" name="password" id="password" class="form-control form-control-lg"
                                    placeholder="Informe sua senha" />
                            </div>
                        </div>

                        <div class="row form-outline mb-5">
                            <div class="d-flex justify-content-start">
                                <label class="form-label" for="password">Confirmar senha:</label>
                            </div>
                            <div class="d-flex justify-content-center">
                                <input type="password" name="password_confirmation" id="password_confirmation"
                                    class="form-control form-control-lg" placeholder="Informe sua senha" />
                            </div>
                        </div>


                        <div class="text-center text-lg-start  d-flex justify-content-center mb-3">
                            <button type="submit" class="btn btn-primary btn-lg"
                                style="padding-left: 2.5rem; padding-right: 2.5rem;">
                                Cadastrar
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div
            class="d-flex flex-column flex-md-row text-center text-md-start justify-content-center py-4 px-4 px-xl-5 bg-primary">
            <div class="text-white mb-3 mb-md-0">
                Copyright © 2023. All rights reserved.
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\document-app\resources\views/users/create.blade.php ENDPATH**/ ?>