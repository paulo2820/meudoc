<nav class="sb-topnav navbar navbar-expand navbar-light bg-light border-bottom shadow">
    <!--Navbar Brand -->
    <h2 class="m-4"><strong>PMK</strong><em class="text-primary"><strong>DOCS</strong></em></h2>
    <!-- Sidebar Toggle -->
    <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0 m-4" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
    <!-- Button Logout -->
    <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
        <div class="input-group">
            <a href=" <?php echo e(route('logout')); ?>" class="btn btn-primary"><i class="far fa-user"></i> LOGOUT</a>
        </div>
    </form>
</nav>
<?php /**PATH C:\www\document-app\resources\views/template/navbar.blade.php ENDPATH**/ ?>