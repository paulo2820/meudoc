<?php $__env->startSection('content'); ?>
    <!-- CONTENT -->

    <div class="docs-content">
        <article class="docs-article">
            <section class="docs-section shadow mt-3">
                <div class="p-3">
                    <h1 class="docs-heading">Seja Bem vindo ao PMK Docs</h1>
                    <p>
                        Esta Documentação foi criada para auxiliar o usuário nos serviços e regras de négocio da empresa!
                    </p>
                    <p>
                        Ao lado esquerdo encontra-se os Documentos disponiveis para consulta.
                    </p>
                </div>
            </section>
        </article>
    </div>
    <!-- CONTENT -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.document-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\document-app\resources\views/document-view/index.blade.php ENDPATH**/ ?>