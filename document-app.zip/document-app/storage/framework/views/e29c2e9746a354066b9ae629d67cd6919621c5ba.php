<div id="docs-sidebar" class="docs-sidebar shadow">
    <nav id="docs-nav" class="docs-nav navbar">
        <ul class="section-items list-unstyled nav flex-column">

            


            <?php $__currentLoopData = version(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $document->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item section-title">
                        <a href="<?php echo e(route('view-document.show', ['document' => $documents->name . "_" . $document->max_version])); ?>" class="nav-link">
                            <span class="theme-icon-holder ">
                                #
                            </span>
                            <?php echo $documents->name; ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            

        </ul>
    </nav>
</div>
<?php /**PATH C:\www\document-app\resources\views/template/document-sidebar.blade.php ENDPATH**/ ?>