<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4 mb-4 col-md-8"><strong><em>Visualizar</strong> <strong class="text-primary">Documentos Cadastrados</em></strong></h1>

            <?php if(isset($mensagemSucesso)): ?>
                <div class="d-flex col-md-12 alert alert-success justify-content-center mt-3">
                    <?php echo e($mensagemSucesso); ?>

                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('bussiness-rule-table', [])->html();
} elseif ($_instance->childHasBeenRendered('9LwOCI7')) {
    $componentId = $_instance->getRenderedChildComponentId('9LwOCI7');
    $componentTag = $_instance->getRenderedChildComponentTagName('9LwOCI7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9LwOCI7');
} else {
    $response = \Livewire\Livewire::mount('bussiness-rule-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('9LwOCI7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </main>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\document-app\resources\views/bussiness-rule/index.blade.php ENDPATH**/ ?>