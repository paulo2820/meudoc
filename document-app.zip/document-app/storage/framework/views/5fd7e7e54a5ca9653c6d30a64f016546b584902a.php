<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4 mb-4 col-md-12"><strong><em>Visualizar</strong> <strong class="text-primary">Documentos de Desenvolvimento Cadastrados</em></strong></h1>

            <?php if(isset($mensagemSucesso)): ?>
                <div class="d-flex col-md-12 alert alert-success justify-content-center mt-3">
                    <?php echo e($mensagemSucesso); ?>

                </div>
            <?php endif; ?>

            <div class="card">
                
                <div class="card-body">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('developer-table', [])->html();
} elseif ($_instance->childHasBeenRendered('yGJ7TB2')) {
    $componentId = $_instance->getRenderedChildComponentId('yGJ7TB2');
    $componentTag = $_instance->getRenderedChildComponentTagName('yGJ7TB2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yGJ7TB2');
} else {
    $response = \Livewire\Livewire::mount('developer-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('yGJ7TB2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    

                            
                                
                                

                            <!-- MODAL DELETE -->
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\document-app\resources\views/developer/index.blade.php ENDPATH**/ ?>