<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4 mb-4 col-md-8"><strong><em>Visualizar</strong> <strong class="text-primary">Sub Documentos Cadastrados</em></strong></h1>

            <?php if(isset($mensagemSucesso)): ?>
                <div class="alert alert-success text-center mt-3">
                    <?php echo e($mensagemSucesso); ?>

                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sub-document-table', [])->html();
} elseif ($_instance->childHasBeenRendered('jnUN6FL')) {
    $componentId = $_instance->getRenderedChildComponentId('jnUN6FL');
    $componentTag = $_instance->getRenderedChildComponentTagName('jnUN6FL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jnUN6FL');
} else {
    $response = \Livewire\Livewire::mount('sub-document-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('jnUN6FL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>

            </div>
        </div>
    </main>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\document-app\resources\views/sub-document/index.blade.php ENDPATH**/ ?>