    <!-- Javascript -->
    <script src="<?php echo e(asset('assets/plugins/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>

    <!-- JQUERY -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Page Specific JS -->
    <script src="<?php echo e(asset('assets/plugins/smoothscroll.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/9.15.8/highlight.min.js"></script>
    <script src="<?php echo e(asset('assets/js/highlight-custom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/simplelightbox/simple-lightbox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/gumshoe/gumshoe.polyfills.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/docs.js')); ?>"></script>
<?php /**PATH C:\www\document-app\resources\views/template/document-scripts.blade.php ENDPATH**/ ?>