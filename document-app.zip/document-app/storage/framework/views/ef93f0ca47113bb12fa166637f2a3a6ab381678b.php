<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">
            <div class="d-flex">
                <div class="col-md-12"><h1 class="mt-4 mb-4"><strong><em>Criar Descrição de</strong> <strong class="text-primary">Desenvolvedor</em></strong></h1></div>
            </div>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="card mb-4">
                <div class="card-body">
                    <form action="<?php echo e(route('developer.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">

                            <div class="form-group col-md-4">
                                <label for="exampleFormControlSelect1">Documento</label>
                                <select name="name" class="form-control form-control-lg" id="exampleFormControlSelect1">
                                    <option value="">Selecione um Documento</option>
                                    <?php $__currentLoopData = $bussinessRules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bussinessRule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($bussinessRule->name); ?>"><?php echo e($bussinessRule->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <textarea name="description_project" cols="30" rows="10"></textarea>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 d-flex justify-content-center">
                                <button type="submit" class="btn btn-primary btn-lg mt-2">Enviar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\document-app\resources\views/developer/create.blade.php ENDPATH**/ ?>