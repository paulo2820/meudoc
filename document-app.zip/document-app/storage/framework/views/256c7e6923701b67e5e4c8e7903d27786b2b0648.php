<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4 mb-4"><strong><em>Editar Documento:</strong> <strong class="text-primary">Regra de Negócio</em></strong></h1>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="card mb-4">
                <div class="card-body">
                    <form action="<?php echo e(route('bussiness-rule.update', ['bussiness_rule' => $bussinessRule])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label for="name">Nome do Documento</label>
                                <input name="name" class="form-control form-control-lg" type="text" value="<?php echo e($bussinessRule->name); ?>">
                            </div>

                            <div class="form-group col-md-4">
                                <label for="exampleFormControlSelect1">Empresa</label>
                                <select name="id_client" class="form-control form-control-lg" id="exampleFormControlSelect1">
                                    <option value="">Selecione uma Empresa</option>
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <option value="<?php echo e($client->id); ?>" <?php if(old('id_client') == $client->id): ?> selected <?php endif; ?>><?php echo e($client->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group col-md-4">
                                <label for="exampleFormControlSelect1">Projeto</label>
                                <select name="id_project" class="form-control form-control-lg" id="exampleFormControlSelect1">
                                    <option value="">Selecione um Projeto</option>
                                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <option value="<?php echo e($project->id); ?>" <?php if(old('id_project') == $project->id): ?> selected <?php endif; ?>><?php echo e($project->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <textarea name="description" cols="30" rows="10"><?php echo old('description', $bussinessRule->description); ?></textarea>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 d-flex justify-content-center">
                                <button type="submit" class="btn btn-primary btn-lg mt-2">Enviar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\document-app\resources\views/bussiness-rule/edit.blade.php ENDPATH**/ ?>