<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4 mb-4 col-md-8"><strong><em>Visualizar</strong> <strong class="text-primary">Sub Documentos Cadastrados</em></strong></h1>

            

            <div class="card">
                <div class="card-body">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sub-document-table', [])->html();
} elseif ($_instance->childHasBeenRendered('HlTdssB')) {
    $componentId = $_instance->getRenderedChildComponentId('HlTdssB');
    $componentTag = $_instance->getRenderedChildComponentTagName('HlTdssB');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('HlTdssB');
} else {
    $response = \Livewire\Livewire::mount('sub-document-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('HlTdssB', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </main>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www\document-app\resources\views/sub-document-version/index.blade.php ENDPATH**/ ?>