<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('template.users-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
    <?php echo $__env->make('template.users-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php /**PATH C:\www\document-app\resources\views/template/users.blade.php ENDPATH**/ ?>