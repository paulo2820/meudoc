<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\{
    SubDocumentController,
    DocumentController,
    DocumentVersionController,
    SubDocumentVersionController,
    TypeController
};

use App\Http\Controllers\LoginController;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\ViewDocumentController;

# ----------------------- Rota - INICIAL (DASHBOARD) ----------------------- #
Route::get('/',  function () {
    return redirect()->route('document-version.index');
});

# ----------------------- Rota - LOGIN ----------------------- #
Route::get('/login', [LoginController::class, 'index'])->name('login');
Route::post('/login', [LoginController::class, 'login'])->name('login.store');
Route::get('/logout', [LoginController::class, 'logout'])->name('logout');

# ----------------------- Rota - USERS ----------------------- #
Route::get('/register', [UsersController::class, 'create'])->name('users.create');
Route::post('/register',[UsersController::class, 'store'])->name('users.store');


Route::group(['prefix' => 'admin'], function() {

    # ----------------------- Rotas - DOCUMENTOS ----------------------- #
    Route::prefix('document')->controller(DocumentController::class)->group(function(){
        // Route::get('/', 'index')->name('document.index');
        Route::get('/create', 'create')->name('document.create');
        Route::post('/document', 'store')->name('document.store');
        Route::get('/{document}/edit', 'edit')->name('document.edit');
        Route::post('/{document}/update', 'update')->name('document.update');
        Route::get('/{document}', 'show')->name('document.show');
        Route::delete('/destroy/{document}', 'destroy')->name('document.destroy');
    });

    # ----------------------- Rotas - DOCUMENTOS VERSION ----------------------- #
    Route::prefix('document-version')->controller(DocumentVersionController::class)->group(function() {
        Route::get('/', 'index')->name('document-version.index');
        Route::get('/create', 'create')->name('document-version.create');
        Route::post('/document-version', 'store')->name('document-version.store');
        Route::get('/{document}/edit', 'edit')->name('document-version.edit');
        Route::post('/{document}/update', 'update')->name('document-version.update');
        // Route::get('/{document}', 'show')->name('document-version.show');
        Route::delete('/destroy/{document}', 'destroy')->name('document-version.destroy');
        // Edita duplicate
        Route::get('/{document}/edit-duplicate', 'editDuplicate')->name('document-version.edit-duplicate');
        // Cria duplicate
        Route::post('/{id_document_version}/create-duplicate', 'storeDuplicate')->name('document-version.store-duplicate');
    });

    # ----------------------- Rotas - TIPOS DE DOCUMENTOS ----------------------- #
    Route::prefix('type')->controller(TypeController::class)->group(function(){
        Route::get('/create', 'create')->name('type.create');
        Route::post('/type', 'store')->name('type.store');
        Route::get('/{type}/edit', 'edit')->name('type.edit');
        Route::post('/{type}/update', 'update')->name('type.update');
        Route::delete('/destroy/{type}', 'destroy')->name('type.destroy');
    });

    # ----------------------- Rotas - SUB DOCUMENTOS ----------------------- #
    Route::prefix('sub-document')->controller(SubDocumentController::class)->group(function() {
        Route::get('/', 'index')->name('sub-document.index');
        Route::get('/create', 'create')->name('sub-document.create');
        Route::post('/document', 'store')->name('sub-document.store');
        Route::get('/{document}/edit', 'edit')->name('sub-document.edit');
        Route::post('/{document}/update', 'update')->name('sub-document.update');
        Route::get('/{document}', 'show')->name('sub-document.show');
        Route::delete('/destroy/{document}', 'destroy')->name('sub-document.destroy');
    });

    # ----------------------- Rotas - SUB DOCUMENTOS VERSION ----------------------- #
    // Route::prefix('sub-document-version')->controller(SubDocumentVersionController::class)->group(function() {
    //     Route::get('/', 'index')->name('sub-document-version.index');
    //     Route::get('/create', 'create')->name('sub-document-version.create');
    //     Route::post('/document', 'store')->name('sub-document-version.store');
    //     Route::get('/{document}/edit', 'edit')->name('sub-document-version.edit');
    //     Route::post('/{document}/update', 'update')->name('sub-document-version.update');
    //     Route::delete('/destroy/{document}', 'destroy')->name('sub-document-version.destroy');
    // });

});

# ----------------------- Rota - DOCUMENTAÇÃO ----------------------- #
Route::prefix('view-document')->controller(ViewDocumentController::class)->group(function() {
    Route::get('/', 'index')->name('view-document.index');
    Route::get('/{document}', 'show')->name('view-document.show');
});
