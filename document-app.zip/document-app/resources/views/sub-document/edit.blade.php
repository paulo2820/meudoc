@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4 mb-4"><strong><em>Editar Documento:</strong> <strong class="text-primary"> {{ $document->name }} {{ $document->version }} </em></strong></h1>

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card mb-4">
                <div class="card-body">
                    <form action="{{ route('sub-document.update', ['document' => $document]) }}" method="post">
                        @csrf
                        @method('POST')
                        <div class="form-row">

                            <div class="form-group col-md-4">
                                <label for="name">Editar Nome do Documento</label>
                                <input name="name" class="form-control form-control-lg" type="text" value="{{$document->name}}">
                            </div>

                            <div class="form-group col-md-3">
                                <label for="id_document_versions">Documentação</label>
                                <select name="id_document_versions" class="form-control form-control-lg">
                                    <option value="">Selecione o Documento</option>
                                    @foreach ( $documents as $doc )
                                        @foreach ( $doc->documentVersions as $documentVersion )
                                            <option value="{{ $documentVersion->id }}"> {{ $doc->name }} - {{$documentVersion->version}} - {{ ($doc->types)->name }}</option>
                                        @endforeach
                                    @endforeach
                                </select>
                            </div>

                            <div class="form-group col-md-3">
                                <label for="type">Tipo do Documento</label>
                                <select name="type" class="form-control form-control-lg">
                                    <option value="">Selecione tipo do Documento</option>
                                    @foreach ( $types as $type )
                                        <option value="{{$type->id}}" @if(old('id_type') == $type->id) selected @endif>{{$type->name}}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <textarea name="description" cols="30" rows="10"> {{$document->description}} </textarea>
                                </div>
                            </div>

                        </div>

                        <div class="row">
                            <div class="col-md-12 d-flex justify-content-center">
                                <button type="submit" class="btn btn-primary btn-lg mt-2">Atualizar</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </main>
@endsection
