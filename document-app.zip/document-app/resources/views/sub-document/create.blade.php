@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <div class="d-flex">
                <div class="col-6"><h1 class="mt-4 mb-4"><strong><em>Criar</strong> <strong class="text-primary">Sub Documento</em></strong></h1></div>
            </div>

            @isset($mensagemSucesso)
                <div class="alert alert-success text-center mt-3">
                    {{ $mensagemSucesso }}
                </div>
            @endisset

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card mb-4">
                <div class="card-body">
                    <div class="row d-flex">
                        <div class="col-12">
                            <form action="{{ route('sub-document.store') }}" method="post">
                                @csrf
                                <div class="form-row">

                                    <div class="form-group col-md-4">
                                        <label for="name">Nome do Sub Documento</label>
                                        <input name="name" class="form-control form-control-lg" type="text" value="{{ old('name') }}">
                                    </div>

                                    <div class="form-group col-md-4">
                                        <label for="id_document_versions">Documentação</label>
                                        <select name="id_document_versions" class="form-control form-control-lg">
                                            <option value="">Selecione o Documento</option>
                                            @foreach ( $documents as $document )
                                                @foreach ( $document->documentVersions as $documentVersion )
                                                    <option value="{{ $documentVersion->id }}" @if (old('id_document_versions') == $documentVersion->id) selected @endif> {{ $document->name }} - {{$documentVersion->version}} - {{ ($document->types)->name }}</option>
                                                @endforeach
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="form-group col-md-2">
                                        <label for="type">Tipo do Documento</label>
                                        <select name="type" class="form-control form-control-lg">
                                            <option value="">Selecione o Tipo</option>
                                                @foreach ( $types as $type )
                                                    <option value="{{ $type->id }}" @if (old('type') == $type->id) selected @endif> {{ $type->name }} </option>
                                                @endforeach
                                        </select>
                                    </div>

                                    <div class="form-group col-md-2">
                                        <label for="date_document">Data</label>
                                        <input type="date" class="form-control form-control-lg" id="date_document" name="date_document">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <textarea name="description" cols="30" rows="10"> {{ old('description') }} </textarea>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12 d-flex justify-content-center">
                                        <button type="submit" class="btn btn-primary btn-lg mt-2">Cadastrar</button>
                                    </div>
                                </div>

                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </main>
@endsection

{{-- <div class="form-group col-md-2">
    <label for="version">Versão</label>
    <input type="text" class="form-control form-control-lg">
</div>

<div class="row">
    <div class="col-md-12">
        <textarea name="description" cols="30" rows="10"></textarea>
    </div>
</div> --}}
