@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4 mb-4"><strong><em>Editar Documento:</strong> <strong class="text-primary"> {{ $document->name }} </em></strong></h1>

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card mb-4">
                <div class="card-body">
                    <form action="{{ route('document.update', ['document' => $document]) }}" method="post">
                        @csrf
                        @method('POST')
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="name">Nome do Documento</label>
                                <input name="name" class="form-control form-control-lg" type="text" value="{{$document->name}}">
                            </div>

                            <div class="form-group col-md-6">
                                <label for="type">Tipo do Documento</label>
                                <select name="type" class="form-control form-control-lg">
                                    <option value="">Selecione um tipo de Documento</option>
                                    @foreach ( $types as $type )
                                        <option value="{{$type->id}}" @if(old('id_type') == $type->id) selected @endif>{{$type->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12 d-flex justify-content-center">
                                <button type="submit" class="btn btn-primary btn-lg mt-2">Atualizar</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </main>
@endsection
