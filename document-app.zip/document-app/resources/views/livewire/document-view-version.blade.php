<section class="docs-section shadow mt-3">
    <div class="p-3">
        <div class="row mb-4">
            <div class="col-12 d-flex justify-content-center">
                <div class="col-md-2">
                    <label for="">Versões</label>
                    <select class="form-select" wire:model="documentId" wire:change="filterVersionByDocumentVersion">
                        @foreach ( $documentVersion as $documentVersion)
                            <option value="{{ $documentVersion->version }}"> {{ $documentVersion->version }} </option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-3">
                    <label for="">Sub Documentos</label>
                    <select id="select-text" class="form-select">
                        <option value=""> Selecione um Sub Documento </option>
                        @if($documentSearch)
                            @foreach ($documentSearch as $document)
                                @foreach ($document->subDocuments as $subDocument)
                                    <option value="{{ $subDocument->name }}"> {{ $subDocument->name }} </option>
                                @endforeach
                            @endforeach
                        @endif
                    </select>
                </div>
            </div>
        </div>

        @if($documentSearch)
            @foreach ($documentSearch as $document)
                {{-- Documento Principal --}}
                @foreach ( $document->documents as $doc )
                    <section>
                        <h1 class="docs-heading"> {!! $doc->name !!} {{$document->version}} - {!! ($doc->types)->name !!}</h1>
                        <p>{{ \Carbon\Carbon::createFromFormat('Y-m-d', $document->date_document)->format('d/m/Y') }}</p>
                        <p>{!! $document->description !!}</p>
                    </section>
                @endforeach

                {{-- Sub Documentos --}}
                @foreach ($document->subDocuments as $subDocument)
                    <section class="docs-section" id="{!! $subDocument->name  !!}">
                        <h2 class="section-heading"># {!! $subDocument->name  !!}</h2>
                        <p>{!! $subDocument->description !!}</p>
                    </section>
                @endforeach
            @endforeach
        @endif
    </div>
</section>





