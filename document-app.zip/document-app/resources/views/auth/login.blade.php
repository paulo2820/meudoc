@extends('template.login-index')
@section('content')
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <section class="vh-100">
        <div class="container-fluid h-custom">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-md-9 col-lg-6 col-xl-5">
                    <img src="{{ asset('assets/images/imagem.jpg') }}" class="img-fluid" alt="imagem ilustrativa">
                </div>
                <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
                    <form method="post">
                        {{-- action="{{ route('login.store')}}" --}}
                        @csrf
                        @method('POST')
                        <div>
                            <div class="d-flex justify-content-center ">
                                <h1>Login</h1>
                            </div>
                            <div class="d-flex justify-content-center">
                                <h1>PMK<em class="text-primary">Docs</em></h1>
                            </div>
                        </div>

                        <!-- Email input -->
                        <div class="form-outline mb-4">
                            <input type="email" name="email" id="email" value="{{ old('email') }}"
                                class="form-control form-control-lg" placeholder="Informe seu email" />
                            <label class="form-label" for="email">Endereço de email</label>
                        </div>

                        <!-- Password input -->
                        <div class="form-outline mb-3">
                            <input type="password" name="password" id="password" class="form-control form-control-lg"
                                placeholder="Informe sua senha" />
                            <label class="form-label" for="password">Senha</label>
                        </div>

                        <div class="d-flex justify-content-between align-items-center">
                            <a href="#!" class="text-body">Esqueceu a senha?</a>
                        </div>

                        <div class="text-center text-lg-start mt-4 pt-2">
                            <button type="submit" class="btn btn-primary btn-lg"
                                style="padding-left: 2.5rem; padding-right: 2.5rem;">
                                Entrar
                            </button>
                            <p class="small fw-bold mt-2 pt-1 mb-0">
                                Não possui uma conta?
                                <a href="{{ route('users.create') }}" class="link-danger">Registrar</a>
                            </p>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div
            class="d-flex flex-column flex-md-row text-center text-md-start justify-content-center py-4 px-4 px-xl-5 bg-primary">

            <div class="text-white mb-3 mb-md-0">
                Copyright © 2023. All rights reserved.
            </div>
        </div>

    </section>
@endsection
