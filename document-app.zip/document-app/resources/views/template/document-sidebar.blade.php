<div id="docs-sidebar" class="docs-sidebar shadow">
    <nav id="docs-nav" class="docs-nav navbar">
        <ul class="section-items list-unstyled nav flex-column">

            {{-- @foreach (document() as $document)
                @foreach ($document->documentVersions as $documentVersion)
                    <li class="nav-item section-title">
                        <a  href="{{ route('view-document.show', ['document' => $document->name . "_" . $documentVersion->version])}}" class="nav-link">
                            <span class="theme-icon-holder ">
                                #
                            </span>
                            {{ $document->name }} {{ $documentVersion->version }}
                        </a>
                    </li>
                @endforeach
            @endforeach --}}


            @foreach (version() as $document)
                @foreach ( $document->documents as $documents)
                    <li class="nav-item section-title">
                        <a href="{{ route('view-document.show', ['document' => $documents->name . "_" . $document->max_version])}}" class="nav-link">
                            <span class="theme-icon-holder ">
                                #
                            </span>
                            {!! $documents->name !!}
                        </a>
                    </li>
                @endforeach
            @endforeach

            {{-- @if($documentSearch)
                @foreach ( documentSearch as $document )
                    @foreach ( $document->documents as $doc )
                        <li class="nav-item section-title">
                            <a  href="{{ route('view-document.show', ['document' => $document->name . "_" . $documentVersion->version])}}" class="nav-link">
                                <span class="theme-icon-holder me-2">
                                    <i class="fas fa-file-alt"></i>
                                </span>
                                {{ $document->name }} {{ $documentVersion->version }}
                            </a>
                        </li>
                @endforeach
            @endif --}}

        </ul>
    </nav>
</div>
