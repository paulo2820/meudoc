<!DOCTYPE html>
<html lang="pt-br">
    <head>
        @include('template.auth-head')
    </head>

	<body class="p-0">
        @yield('content')
	</body>

    @include('template.auth-scripts')
</html>
