<title>Documentação - PMK</title>

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Documentação PMK">

<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<script defer src= {{ asset("assets/fontawesome/js/all.min.js") }}></script>
{{-- <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.15.2/styles/atom-one-dark.min.css"> --}}
<link rel="stylesheet" href= {{ asset("assets/plugins/simplelightbox/simple-lightbox.min.css")}}>
<link id="theme-style" rel="stylesheet" href= {{ asset("css/content.css") }}>
<link id="theme-style" rel="stylesheet" href= {{ asset("assets/css/theme.css") }}>
