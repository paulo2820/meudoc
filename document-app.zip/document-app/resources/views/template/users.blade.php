<!DOCTYPE html>
<html lang="en">
<head>
    @include('template.users-head')
</head>
<body>
    @yield('content')
</body>
    @include('template.users-scripts')
</html>
