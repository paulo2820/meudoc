@extends('template.index')
@section('content')
    <main>
        <div class="container-fluid px-4">
            <div class="d-flex">
                <div class="col-12">
                    <h1 class="mt-4 mb-4"><strong><em>Duplicar Documento:</strong> <strong class="text-primary">{{$name[0]}} {{$document->version}}</em></strong></h1>
                </div>
            </div>

            @isset($mensagemSucesso)
                <div class="alert alert-success justify-content-center mt-3">
                    {{ $mensagemSucesso }}
                </div>
            @endisset

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card mb-4">
                <div class="card-body">
                    <div class="row d-flex">
                        <div class="col-12">

                            <div class="card mb-4">
                                <div class="card-body">
                                    <form action="{{ route('document-version.store-duplicate', ['id_document_version' => $document->id]) }}" method="post">
                                        @csrf
                                        @method('POST')
                                        <div class="form-row">
                                            <div class="form-group col-md-4" hidden>
                                                <label for="id_document">Documento ID document versions</label>
                                                <input name="id_document" class="form-control form-control-lg" type="text" value="{{$document->id_document}}">
                                            </div>

                                            <div class="form-group col-md-2">
                                                <label for="version">Versão do Documento</label>
                                                <input name="version" class="form-control form-control-lg" type="text" value="{{$document->version}}">
                                            </div>

                                            <div class="form-group col-md-2">
                                                <label for="date_document">Data</label>
                                                <input type="date" class="form-control form-control-lg" id="date_document"
                                                    name="date_document">
                                            </div>

                                            <div class="row">
                                                <div class="col-md-12">
                                                    <textarea name="description" cols="30" rows="10">{{$document->description}}</textarea>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-12 d-flex justify-content-center">
                                                <button type="submit" class="btn btn-primary btn-lg mt-2">Duplicar</button>
                                            </div>
                                        </div>

                                    </form>
                                </div>
                            </div>
                            {{-- <form action="{{ route('document-version.store-duplicate') }}" method="post">
                                @csrf
                                <div class="form-row align-items-center">
                                    <div class="form-group col-md-4">
                                        <label for="id_document">Documento</label>
                                        <select name="id_document" class="form-control form-control-lg">
                                            <option value="">Selecione o Documento</option>
                                            @foreach ($id_documents as $id_document)
                                                <option value="{{ $id_document->id }}"
                                                    @if (old('id_document') == $id_document->id) selected @endif>
                                                    {{ $id_document->name }} - {{ $id_document->types->name }} </option>
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="form-group col-md-2">
                                        <label for="version">Informar Versão</label>
                                        <input name="version" type="text" value="{{ old('version') }}"
                                            class="form-control form-control-lg">
                                    </div>

                                    <div class="form-group col-md-2">
                                        <label for="date_document">Data</label>
                                        <input type="date" class="form-control form-control-lg" id="date_document"
                                            name="date_document">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12">
                                        <textarea name="description" cols="30" rows="10"> {{ old('description') }} </textarea>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12 d-flex justify-content-center">
                                        <button type="submit" class="btn btn-primary btn-lg mt-2"
                                            name="cadastrar">Cadastrar</button>
                                    </div>
                                </div>

                            </form> --}}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
@endsection
