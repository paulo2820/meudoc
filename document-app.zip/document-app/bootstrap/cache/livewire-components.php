<?php return array (
  'document-table' => 'App\\Http\\Livewire\\DocumentTable',
  'document-view-version' => 'App\\Http\\Livewire\\DocumentViewVersion',
  'sub-document-table' => 'App\\Http\\Livewire\\SubDocumentTable',
);