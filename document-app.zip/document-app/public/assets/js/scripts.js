$(document).ready(function()
{
    // Deletar Documento Princiapl Versão
    $('.deleteDocumentVersionBtn').click(function(e){
        e.preventDefault();

        const document_version_id = $(this).val();
        const result = document_version_id.split("|");

        $('#document_version_id').val(result[0]);
        $('#document_version_name').text(result[1]);
        $('#deleteModal').modal('show');
    });

    // Deletar Documento
    $('.deleteDocumentBtn').click(function(e){
        e.preventDefault();

        const document_id = $(this).val();
        const result = document_id.split("|");

        $('#document_id').val(result[0]);
        $('#document_name').text(result[1]);
        $('#deleteModal').modal('show');
    });

    // Deletar Sub Documento
    $('.deleteSubDocumentBtn').click(function(e){
        e.preventDefault();

        const sub_document_id = $(this).val();
        const result = sub_document_id.split("|");

        $('#sub_document_id').val(result[0]);
        $('#sub_document_name').text(result[1]);
        $('#deleteModal').modal('show');
    });

    // Deletar Tipo de Documento
    $('.deleteTypeBtn').click(function(e){
        e.preventDefault();

        const type_id = $(this).val();
        const result = type_id.split("|");

        $('#type_id').val(result[0]);
        $('#type_name').text(result[1]);
        $('#deleteModal').modal('show');
    });
});

// Obtém o elemento input date
var inputDate = $("#date_document");

// Cria um objeto Date com a data atual
var now = new Date();
var formattedDate = now.getFullYear() + "-" + (now.getMonth() + 1).toString().padStart(2, "0") + "-" + now.getDate().toString().padStart(2, "0");

// Define o valor do campo input date para a data atual
inputDate.val(formattedDate);
